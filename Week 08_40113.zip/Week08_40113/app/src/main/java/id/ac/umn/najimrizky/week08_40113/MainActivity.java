package id.ac.umn.najimrizky.week08_40113;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import id.ac.umn.najimrizky.week08_40113.savedInstaceSharedPref.SavedInstanceSharedPref;
import id.ac.umn.najimrizky.week08_40113.textEditorAndStorage.TextEditorStorage;

public class MainActivity extends AppCompatActivity {
    private Button activityA, activityB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        activityA = findViewById(R.id.activityA);
        activityB = findViewById(R.id.activityB);

        activityA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentA = new Intent(MainActivity.this, TextEditorStorage.class);
                startActivity(intentA);
            }
        });

        activityB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentB = new Intent(MainActivity.this, SavedInstanceSharedPref.class);
                startActivity(intentB);
            }
        });
    }
}