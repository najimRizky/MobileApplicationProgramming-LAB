package id.ac.umn.najimrizky.week12_40113;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import id.ac.umn.najimrizky.week12_40113.activity_a.DeteksiSensor;
import id.ac.umn.najimrizky.week12_40113.activity_b.PembacaanDataSensor;

public class MainActivity extends AppCompatActivity {
    Button activity_a, activity_b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        activity_a = findViewById(R.id.activity_a);
        activity_b = findViewById(R.id.activity_b);

        activity_a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(MainActivity.this, DeteksiSensor.class);
                startActivity(intent1);
            }
        });

        activity_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(MainActivity.this, PembacaanDataSensor.class);
                startActivity(intent2);
            }
        });

    }
}