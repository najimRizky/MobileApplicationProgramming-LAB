package id.ac.umn.najimrizky.week01_40113;

import androidx.appcompat.app.AppCompatActivity;

//import android.support.v7.app.AppCompactActivity;
import android.os.Bundle;
//import android.support.v7.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}