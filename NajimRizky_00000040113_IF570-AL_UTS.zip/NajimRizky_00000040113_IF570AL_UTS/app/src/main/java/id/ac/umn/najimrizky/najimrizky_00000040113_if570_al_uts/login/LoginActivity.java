package id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.R;
import id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.library.LibraryActivity;

public class LoginActivity extends AppCompatActivity {
    private Button btnLogin;
    private EditText etUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = findViewById(R.id.btnLogin);
        etUsername = findViewById(R.id.etUsername);
        getSupportActionBar().hide();


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = etUsername.getText().toString();
                if(username.length() ==0 ){
                    etUsername.setError("Harap diisi");
                }else{
                    Intent toLibrary = new Intent(LoginActivity.this, LibraryActivity.class);
                    toLibrary.putExtra("user",username);
                    startActivity(toLibrary);
                }
            }
        });

    }
}