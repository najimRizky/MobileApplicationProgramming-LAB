package id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.library;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.LinkedList;

import id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.MainActivity;
import id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.R;
import id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.profile.ProfileActivity;

public class LibraryActivity extends AppCompatActivity {
    RecyclerView rvDaftarAudio;
    DaftarAudioAdapter mAdapter;
    LinkedList<SumberAudio> daftarAudio = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        Intent fromLogin = getIntent();
        String username = fromLogin.getStringExtra("user");
        getSupportActionBar().setTitle(username);
        isiDaftarAudio();
        rvDaftarAudio = (RecyclerView) findViewById(R.id.recyclerView);
        mAdapter = new DaftarAudioAdapter(this,daftarAudio);
        rvDaftarAudio.setAdapter(mAdapter);
        rvDaftarAudio.setLayoutManager(new LinearLayoutManager(this));
        showToast(username);

    }
    public void isiDaftarAudio() {
        daftarAudio.add(new SumberAudio("Dragon Spine", "Gennshin Impact OST.",  Integer.toString(R.raw.dragonspine) ));
        daftarAudio.add(new SumberAudio("Uhhh", "Roblox Death Sound Effect", Integer.toString(R.raw.uhhroblox) ));
        daftarAudio.add(new SumberAudio("Gunshot", "SFX",  Integer.toString(R.raw.gunshot) ));
        daftarAudio.add(new SumberAudio("Windows XP", "Tech", Integer.toString(R.raw.windowsxp) ));
        daftarAudio.add(new SumberAudio("Bruh", "Meme", Integer.toString(R.raw.bruh) ));
        daftarAudio.add(new SumberAudio("F1", "Racing", Integer.toString(R.raw.f1) ));
        daftarAudio.add(new SumberAudio("Oh Hell No", "Meme", Integer.toString(R.raw.hellno) ));
        daftarAudio.add(new SumberAudio("Moto GP", "Racing", Integer.toString(R.raw.motogp) ));
        daftarAudio.add(new SumberAudio("Piano", "Music", Integer.toString(R.raw.piano) ));
        daftarAudio.add(new SumberAudio("Rain", "Nature", Integer.toString(R.raw.rain) ));
        daftarAudio.add(new SumberAudio("Thunder", "Nature", Integer.toString(R.raw.thunder) ));

    }

    public void showToast(String username){
        Context context = getApplicationContext();
        CharSequence text = "Selamat datang, " + username;
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id == R.id.home){
            startActivity(new Intent(LibraryActivity.this, MainActivity.class));
        }else{
            startActivity(new Intent(LibraryActivity.this, ProfileActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}