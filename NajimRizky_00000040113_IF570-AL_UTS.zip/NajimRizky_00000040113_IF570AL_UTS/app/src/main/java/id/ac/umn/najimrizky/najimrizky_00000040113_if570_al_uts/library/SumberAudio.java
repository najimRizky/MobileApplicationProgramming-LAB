package id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.library;

import java.io.Serializable;
import java.util.LinkedList;

public class SumberAudio  implements Serializable {
    private String judul, keterangan, audioUri;

    public SumberAudio (String judul, String keterangan, String audioUri){
        this.judul = judul;
        this.keterangan = keterangan;
        this.audioUri = audioUri;
    }

    public String getJudul() {
        return this.judul;
    }
    public String getKeterengan() {
        return this.keterangan;
    }
    public String getAudioUri() {
        return this.audioUri;
    }
}
