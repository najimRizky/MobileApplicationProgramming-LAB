package id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.library;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import id.ac.umn.najimrizky.najimrizky_00000040113_if570_al_uts.R;

public class DetilAudioActivity extends AppCompatActivity {
    private MediaPlayer player;
    private TextView judul, keterangan;
    private String audioUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detil_audio);

        judul = findViewById(R.id.judul);
        keterangan = findViewById(R.id.keterangan);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        SumberAudio av = (SumberAudio) bundle.getSerializable("DetilAudio");
        getSupportActionBar().setTitle(av.getJudul());
        judul.setText(av.getJudul());
        keterangan.setText(av.getKeterengan());
        audioUri = av.getAudioUri();

    }

    public void play(View v){
        if (player == null){
            player = MediaPlayer.create(this, Integer.parseInt(audioUri));
        }
        player.start();
    }

    @Override
    protected void onPause(){
        if(player != null){
            player.stop();
            player.reset();
        }
        super.onPause();
    }
}