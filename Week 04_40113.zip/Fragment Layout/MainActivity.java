package id.ac.umn.najimrizky.week03b_40113;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button btn1, btn2;
    private EditText etMain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.main_button_change_1);
        btn2 = findViewById(R.id.main_button_change_2);
        etMain = findViewById(R.id.etMain);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHalaman1();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHalaman2();
            }
        });
    }

    public void openHalaman1(){
        Intent intent = new Intent(this, SecondActivity.class);
        String msgMain = etMain.getText().toString();
        intent.putExtra("Message", msgMain);
        startActivity(intent);
    }

    public void openHalaman2(){
        Intent intent = new Intent(this, ThirdActivity.class);
        startActivity(intent);
    }
}