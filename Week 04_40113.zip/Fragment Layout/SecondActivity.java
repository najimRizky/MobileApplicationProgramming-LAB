package id.ac.umn.najimrizky.week03b_40113;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        SecondFragment secondFragment = new SecondFragment();


        Intent secondIntent = getIntent();
        String mainMsg = secondIntent.getStringExtra("Message");
        if(!mainMsg.isEmpty()){
            secondFragment.changeText(mainMsg);
        }
    }
}