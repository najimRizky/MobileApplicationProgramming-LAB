package id.ac.umn.najimrizky.week03b_40113;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {
    private TextView tv;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_second,container, false);
        return view;
    }


    public void changeText(String text){
        if(getView()!=null){
            tv = getView().findViewById(R.id.tvFragment);
//        tv.setText(text);
        }else{
            System.out.println("kosong");
        }
    }
}
