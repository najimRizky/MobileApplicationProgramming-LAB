package id.ac.umn.najimrizky.week10_40113;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import id.ac.umn.najimrizky.week10_40113.activityA.activityAsyncTask;
import id.ac.umn.najimrizky.week10_40113.activityB.activityAsyncTaskLoader;
import id.ac.umn.najimrizky.week10_40113.activityC.activityStartedService;

public class MainActivity extends AppCompatActivity {
    Button activityA, activityB, activityC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activityA = findViewById(R.id.activityA);
        activityB = findViewById(R.id.activityB);
        activityC = findViewById(R.id.activityC);

        activityA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent actA = new Intent(MainActivity.this, activityAsyncTask.class);
                startActivity(actA);
            }
        });

        activityB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent actB = new Intent(MainActivity.this, activityAsyncTaskLoader.class);
                startActivity(actB);
            }
        });

        activityC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent actB = new Intent(MainActivity.this, activityStartedService.class);
                startActivity(actB);
            }
        });
    }
}